#ifndef HG_REVISION_H
#define HG_REVISION_H

#ifndef HG_REV
#define HG_REV "unknown revision"
#endif

#endif // HG_REVISION_H
