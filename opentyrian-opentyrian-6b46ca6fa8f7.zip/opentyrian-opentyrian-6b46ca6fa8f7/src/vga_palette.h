#ifndef VGA_PALETTE_H
#define VGA_PALETTE_H

#include "palette.h"

extern Palette vga_palette;

#endif // VGA_PALETTE_H
